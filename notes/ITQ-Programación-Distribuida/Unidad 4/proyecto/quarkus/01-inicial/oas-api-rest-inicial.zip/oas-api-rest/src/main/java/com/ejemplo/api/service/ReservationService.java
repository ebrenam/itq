package com.ejemplo.api.service;

import com.ejemplo.api.model.CancelConfirmation;
import com.ejemplo.api.model.Confirmation;
import com.ejemplo.api.model.ConfirmationList;
import com.ejemplo.api.model.Reservation;
import com.ejemplo.api.model.ReservationPatch;

import jakarta.enterprise.context.ApplicationScoped; // <-- Importante
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped // Le dice a Quarkus que gestione esta clase como un servicio
public class ReservationService {

    public Confirmation createReservation(Reservation reservation)
    {
        System.out.println("Service - Reservation recibida: " + reservation.getIdClient());

        // Aquí iría la lógica para guardar en la base de datos

        // Simulamos que la DB le asigna un ID
        Confirmation confirmationResponse = new Confirmation();
        confirmationResponse.setIdReservation(12345); // ID simulado
        confirmationResponse.setIdRoom(5); // Sala asignada simulada
        confirmationResponse.setInstructor("Juan Pérez"); // Instructor asignado simulado
        confirmationResponse.setDiscount(null); // Sin descuento por defecto

        return confirmationResponse;
    }

    public ConfirmationList getReservations(String idClient, String activity, String dayOfWeek, String time) {
        System.out.println("Service - Buscando reservas con criterios");
        
        // Aquí iría la lógica para buscar reservas en la base de datos según los criterios
        
        // Simulamos que encontramos algunas reservas
        List<Confirmation> confirmations = new ArrayList<>();
        
        // Simulamos 2 reservas de ejemplo
        Confirmation conf1 = new Confirmation();
        conf1.setIdReservation(12345);
        conf1.setIdRoom(5);
        conf1.setInstructor("María García");
        conf1.setDiscount(10.50);
        confirmations.add(conf1);
        
        Confirmation conf2 = new Confirmation();
        conf2.setIdReservation(12346);
        conf2.setIdRoom(3);
        conf2.setInstructor("Juan Pérez");
        conf2.setDiscount(0.0);
        confirmations.add(conf2);
        
        ConfirmationList confirmationList = new ConfirmationList();
        confirmationList.setConfirmations(confirmations);
        confirmationList.setTotal(confirmations.size());
        
        return confirmationList;
    }

    public Confirmation getReservationById(Integer reservationId)
    {
        System.out.println("Service - Buscando Reservation con ID: " + reservationId);

        // Aquí iría la lógica para buscar la reserva en la base de datos

        // Simulamos que encontramos la reserva
        Confirmation confirmationResponse = new Confirmation();
        confirmationResponse.setIdReservation(reservationId);
        confirmationResponse.setIdRoom(8); // Sala asignada simulada
        confirmationResponse.setInstructor("Ana López"); // Instructor asignado simulado
        confirmationResponse.setDiscount(15.00); // Descuento simulado

        return confirmationResponse;
    }
    
    public Confirmation updateReservation(Integer reservationId, Reservation reservation) {
        System.out.println("Service - Actualizando Reservation con ID: " + reservationId);
        
        // Aquí iría la lógica para actualizar completamente la reserva en la base de datos
        
        // Simulamos que actualizamos la reserva
        Confirmation confirmationResponse = new Confirmation();
        confirmationResponse.setIdReservation(reservationId);
        confirmationResponse.setIdRoom(8); // Nueva sala asignada simulada
        confirmationResponse.setInstructor("Ana López"); // Instructor actualizado simulado
        confirmationResponse.setDiscount(15.00); // Descuento actualizado simulado
        
        return confirmationResponse;
    }
    
    public Confirmation patchReservation(Integer reservationId, ReservationPatch reservationPatch) {
        System.out.println("Service - Actualizando parcialmente Reservation con ID: " + reservationId);
        
        // Aquí iría la lógica para actualizar parcialmente la reserva en la base de datos
        // Solo se actualizarían los campos no nulos del ReservationPatch
        
        // Simulamos que actualizamos parcialmente la reserva
        Confirmation confirmationResponse = new Confirmation();
        confirmationResponse.setIdReservation(reservationId);
        confirmationResponse.setIdRoom(5); // Sala mantenida o actualizada
        confirmationResponse.setInstructor("María García"); // Instructor mantenido o actualizado
        confirmationResponse.setDiscount(10.50); // Descuento mantenido o actualizado
        
        return confirmationResponse;
    }
    
    public CancelConfirmation cancelReservation(Integer reservationId) {
        System.out.println("Service - Cancelando Reservation con ID: " + reservationId);
        
        // Aquí iría la lógica para cancelar la reserva en la base de datos
        
        // Simulamos que cancelamos la reserva exitosamente
        CancelConfirmation cancelConfirmation = new CancelConfirmation();
        cancelConfirmation.setIdReservation(reservationId);
        cancelConfirmation.setStatus(CancelConfirmation.StatusEnum.CANCELLED);
        cancelConfirmation.setMessage("Reserva cancelada exitosamente");
        cancelConfirmation.setCancelledAt(OffsetDateTime.now());
        
        return cancelConfirmation;
    }
}