package com.ejemplo.api.service;

import com.ejemplo.api.entity.ReservationEntity;
import com.ejemplo.api.mapper.ReservationMapper;
import com.ejemplo.api.model.CancelConfirmation;
import com.ejemplo.api.model.Confirmation;
import com.ejemplo.api.model.ConfirmationList;
import com.ejemplo.api.model.Reservation;
import com.ejemplo.api.model.ReservationPatch;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.time.OffsetDateTime;
import java.util.List;

@ApplicationScoped
public class ReservationService {

    @Inject
    ReservationMapper reservationMapper;

    /**
     * Crear una nueva reservación
     */
    @Transactional
    public Confirmation createReservation(Reservation reservation)
    {
        System.out.println("Service - Creando reservación para cliente: " + reservation.getIdClient());
        
        // Convertir el modelo OpenAPI a entidad JPA
        ReservationEntity entity = reservationMapper.toEntity(reservation);
        
        // Persistir en la base de datos
        entity.persist();
        
        // Convertir la entidad guardada a modelo de confirmación
        Confirmation confirmation = reservationMapper.toConfirmation(entity);
        
        System.out.println("Service - Reservación creada con ID: " + entity.id);
        return confirmation;
    }

    /**
     * Obtener todas las reservaciones
     */
    public ConfirmationList getReservations(String idClient, String activity, String dayOfWeek, String time)
    {
        System.out.println("Service - Obteniendo todas las reservaciones");
        
        List<ReservationEntity> entities = ReservationEntity.listAll();
        
        List<Confirmation> confirmations = entities.stream()
                .map(reservationMapper::toConfirmation)
                .toList();
                
        ConfirmationList confirmationList = new ConfirmationList();
        confirmationList.setConfirmations(confirmations);
        confirmationList.setTotal(confirmations.size());
        
        return confirmationList;
    }

    /**
     * Obtener reservación por ID
     */
    public Confirmation getReservationById(Integer reservationId)
    {
        System.out.println("Service - Buscando reservación con ID: " + reservationId);
        
        ReservationEntity entity = ReservationEntity.findById(reservationId.longValue());
        
        if (entity != null) {
            System.out.println("Service - Reservación encontrada: " + entity.toString());
            return reservationMapper.toConfirmation(entity);
        } else {
            System.out.println("Service - Reservación no encontrada con ID: " + reservationId);
            return null;
        }
    }

    /**
     * Actualizar una reservación existente
     */
    @Transactional
    public Confirmation updateReservation(Integer reservationId, Reservation reservation)
    {
        System.out.println("Service - Actualizando reservación con ID: " + reservationId);
        
        ReservationEntity entity = ReservationEntity.findById(reservationId.longValue());
        
        if (entity != null) {
            // Actualizar los campos
            entity.idClient = reservation.getIdClient();
            entity.activity = reservation.getActivity();
            entity.dayOfWeek = reservation.getDayOfWeek().toString();
            entity.time = reservation.getTime();
            
            // Panache automáticamente detecta cambios y los persiste
            System.out.println("Service - Reservación actualizada: " + entity.toString());
            return reservationMapper.toConfirmation(entity);
        } else {
            System.out.println("Service - No se puede actualizar. Reservación no encontrada con ID: " + reservationId);
            return null;
        }
    }

    /**
     * Actualizar parcialmente una reservación existente (PATCH)
     */
    @Transactional
    public Confirmation patchReservation(Integer reservationId, ReservationPatch reservationPatch)
    {
        System.out.println("Service - Actualizando parcialmente reservación con ID: " + reservationId);
        
        ReservationEntity entity = ReservationEntity.findById(reservationId.longValue());
        
        if (entity != null) {
            // Actualizar solo los campos que no son nulos (actualización parcial)
            if (reservationPatch.getIdClient() != null) {
                entity.idClient = reservationPatch.getIdClient();
            }
            if (reservationPatch.getActivity() != null) {
                entity.activity = reservationPatch.getActivity();
            }
            if (reservationPatch.getDayOfWeek() != null) {
                entity.dayOfWeek = reservationPatch.getDayOfWeek().toString();
            }
            if (reservationPatch.getTime() != null) {
                entity.time = reservationPatch.getTime();
            }
            
            // Panache automáticamente detecta cambios y los persiste
            System.out.println("Service - Reservación actualizada parcialmente: " + entity.toString());
            return reservationMapper.toConfirmation(entity);
        } else {
            System.out.println("Service - No se puede actualizar. Reservación no encontrada con ID: " + reservationId);
            return null;
        }
    }

    /**
     * Eliminar una reservación
     */
    @Transactional
    public CancelConfirmation cancelReservation(Integer reservationId)
    {
        System.out.println("Service - Eliminando reservación con ID: " + reservationId);
        
        boolean deleted = ReservationEntity.deleteById(reservationId.longValue());
        
        CancelConfirmation cancelConfirmation = new CancelConfirmation();
        cancelConfirmation.setIdReservation(reservationId);
        
        if (deleted) {
            System.out.println("Service - Reservación eliminada exitosamente");
            cancelConfirmation.setStatus(CancelConfirmation.StatusEnum.CANCELLED);
            cancelConfirmation.setMessage("Reserva cancelada exitosamente");
        } else {
            System.out.println("Service - No se pudo eliminar. Reservación no encontrada con ID: " + reservationId);
            cancelConfirmation.setStatus(CancelConfirmation.StatusEnum.FAILED);
            cancelConfirmation.setMessage("No se pudo cancelar. Reservación no encontrada");
        }
        
        cancelConfirmation.setCancelledAt(OffsetDateTime.now());
        return cancelConfirmation;
    }
}