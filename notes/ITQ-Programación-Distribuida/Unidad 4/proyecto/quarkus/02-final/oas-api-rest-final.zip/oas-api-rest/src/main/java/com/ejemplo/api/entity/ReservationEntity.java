package com.ejemplo.api.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "reservations")
public class ReservationEntity extends PanacheEntity {

    @Column(name = "id_client", nullable = false)
    public String idClient;

    @Column(name = "activity", nullable = false)
    public String activity;

    @Column(name = "day_of_week", nullable = false)
    public String dayOfWeek;

    @Column(name = "time", nullable = false)
    public String time;

    @Column(name = "id_room")
    public Integer idRoom;

    @Column(name = "instructor", length = 100)
    public String instructor;

    @Column(name = "discount", precision = 5, scale = 2)
    public BigDecimal discount;

    @Column(name = "created_at", updatable = false)
    public LocalDateTime createdAt;

    @Column(name = "updated_at")
    public LocalDateTime updatedAt;

    // Métodos de ciclo de vida de JPA
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Método toString para debugging
    @Override
    public String toString() {
        return "ReservationEntity{" +
                "id=" + id +
                ", idClient='" + idClient + '\'' +
                ", activity='" + activity + '\'' +
                ", dayOfWeek='" + dayOfWeek + '\'' +
                ", time='" + time + '\'' +
                ", idRoom=" + idRoom +
                ", instructor='" + instructor + '\'' +
                ", discount=" + discount +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}