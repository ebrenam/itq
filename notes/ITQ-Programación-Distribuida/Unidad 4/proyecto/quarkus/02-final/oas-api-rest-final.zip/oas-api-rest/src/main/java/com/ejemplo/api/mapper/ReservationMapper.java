package com.ejemplo.api.mapper;

import com.ejemplo.api.entity.ReservationEntity;
import com.ejemplo.api.model.Confirmation;
import com.ejemplo.api.model.Reservation;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ReservationMapper {

    /**
     * Convierte de modelo OpenAPI a entidad JPA
     */
    public ReservationEntity toEntity(Reservation reservation)
    {
        if (reservation == null) {
            return null;
        }

        ReservationEntity entity = new ReservationEntity();
        entity.idClient = reservation.getIdClient();
        entity.activity = reservation.getActivity();
        entity.dayOfWeek = reservation.getDayOfWeek() != null ? reservation.getDayOfWeek().toString() : null;
        entity.time = reservation.getTime();

        // Asignar valores por defecto para simplificar
        entity.idRoom = 1; // Sala por defecto
        entity.instructor = "Instructor Asignado"; // Instructor por defecto
        entity.discount = java.math.BigDecimal.valueOf(0.0); // Sin descuento por defecto

        return entity;
    }

    /**
     * Convierte de entidad JPA a modelo de confirmación
     */
    public Confirmation toConfirmation(ReservationEntity entity)
    {
        if (entity == null) {
            return null;
        }

        Confirmation confirmation = new Confirmation();
        confirmation.setIdReservation(entity.id.intValue()); // PanacheEntity usa Long, convertimos a Integer
        confirmation.setIdRoom(entity.idRoom);
        confirmation.setInstructor(entity.instructor);
        
        // Convertir BigDecimal a Double si no es null
        if (entity.discount != null) {
            confirmation.setDiscount(entity.discount.doubleValue());
        }

        return confirmation;
    }

    /**
     * Convierte de entidad JPA a modelo Reservation
     */
    public Reservation toReservation(ReservationEntity entity)
    {
        if (entity == null) {
            return null;
        }

        Reservation reservation = new Reservation();
        reservation.setIdClient(entity.idClient);
        reservation.setActivity(entity.activity);
        reservation.setTime(entity.time);
        
        // Convertir string a enum
        if (entity.dayOfWeek != null) {
            try {
                reservation.setDayOfWeek(Reservation.DayOfWeekEnum.valueOf(entity.dayOfWeek.toUpperCase()));
            } catch (IllegalArgumentException e) {
                reservation.setDayOfWeek(Reservation.DayOfWeekEnum.LUN); // Valor por defecto
            }
        }

        return reservation;
    }
}