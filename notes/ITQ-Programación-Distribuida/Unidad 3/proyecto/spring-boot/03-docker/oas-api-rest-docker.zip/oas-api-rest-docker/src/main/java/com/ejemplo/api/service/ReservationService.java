package com.ejemplo.api.service;

import org.springframework.stereotype.Service;

import com.ejemplo.api.model.Confirmation;
import com.ejemplo.api.model.Reservation;

@Service
public class ReservationService {

    public Confirmation createReservation(Reservation reservation) {
        System.out.println("Service - Reservation recibida: " + reservation.getIdClient());

        // Aquí iría la lógica para guardar en la base de datos

        // Simulamos que la DB le asigna un ID
        Confirmation confirmationResponse = new Confirmation();
        confirmationResponse.setIdReservation(12345); // ID simulado
        confirmationResponse.setIdRoom(5); // Sala asignada simulada
        confirmationResponse.setInstructor("Juan Pérez"); // Instructor asignado simulado
        confirmationResponse.setDiscount(null); // Sin descuento por defecto

        return confirmationResponse;
    }

    public Confirmation getReservationById(Integer reservationId) {
        System.out.println("Service - Buscando Reservation con ID: " + reservationId);

        // Aquí iría la lógica para buscar la reserva en la base de datos

        // Simulamos que encontramos la reserva
        Confirmation confirmationResponse = new Confirmation();
        confirmationResponse.setIdReservation(reservationId);
        confirmationResponse.setIdRoom(8); // Sala asignada simulada
        confirmationResponse.setInstructor("Ana López"); // Instructor asignado simulado
        confirmationResponse.setDiscount(15.00); // Descuento simulado

        return confirmationResponse;
    }
}