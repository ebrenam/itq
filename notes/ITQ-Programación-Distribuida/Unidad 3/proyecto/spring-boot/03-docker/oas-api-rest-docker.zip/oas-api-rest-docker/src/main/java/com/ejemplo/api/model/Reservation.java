package com.ejemplo.api.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import java.io.Serializable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Datos para crear una nueva reserva
 */

@Schema(name = "Reservation", description = "Datos para crear una nueva reserva")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-29T15:49:04.223524-06:00[America/Mexico_City]")
public class Reservation implements Serializable {

  private static final long serialVersionUID = 1L;

  private String idClient;

  private String activity;

  /**
   * Día de la semana
   */
  public enum DayOfWeekEnum {
    LUN("Lun"),
    
    MAR("Mar"),
    
    MIE("Mie"),
    
    JUE("Jue"),
    
    VIE("Vie"),
    
    SAB("Sab"),
    
    DOM("Dom");

    private String value;

    DayOfWeekEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static DayOfWeekEnum fromValue(String value) {
      for (DayOfWeekEnum b : DayOfWeekEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private DayOfWeekEnum dayOfWeek;

  private String time;

  public Reservation() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public Reservation(String idClient, String activity, DayOfWeekEnum dayOfWeek, String time) {
    this.idClient = idClient;
    this.activity = activity;
    this.dayOfWeek = dayOfWeek;
    this.time = time;
  }

  public Reservation idClient(String idClient) {
    this.idClient = idClient;
    return this;
  }

  /**
   * Identificador del cliente
   * @return idClient
  */
  @NotNull @Pattern(regexp = "^[BP]C-[0-9]{3}$") 
  @Schema(name = "idClient", example = "BC-123", description = "Identificador del cliente", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("idClient")
  public String getIdClient() {
    return idClient;
  }

  public void setIdClient(String idClient) {
    this.idClient = idClient;
  }

  public Reservation activity(String activity) {
    this.activity = activity;
    return this;
  }

  /**
   * Nombre de la actividad
   * @return activity
  */
  @NotNull @Size(min = 3, max = 255) 
  @Schema(name = "activity", example = "Yoga", description = "Nombre de la actividad", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("activity")
  public String getActivity() {
    return activity;
  }

  public void setActivity(String activity) {
    this.activity = activity;
  }

  public Reservation dayOfWeek(DayOfWeekEnum dayOfWeek) {
    this.dayOfWeek = dayOfWeek;
    return this;
  }

  /**
   * Día de la semana
   * @return dayOfWeek
  */
  @NotNull 
  @Schema(name = "dayOfWeek", example = "Lun", description = "Día de la semana", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("dayOfWeek")
  public DayOfWeekEnum getDayOfWeek() {
    return dayOfWeek;
  }

  public void setDayOfWeek(DayOfWeekEnum dayOfWeek) {
    this.dayOfWeek = dayOfWeek;
  }

  public Reservation time(String time) {
    this.time = time;
    return this;
  }

  /**
   * Hora de la actividad (formato HH:MM)
   * @return time
  */
  @NotNull 
  @Schema(name = "time", example = "09:00", description = "Hora de la actividad (formato HH:MM)", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("time")
  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Reservation reservation = (Reservation) o;
    return Objects.equals(this.idClient, reservation.idClient) &&
        Objects.equals(this.activity, reservation.activity) &&
        Objects.equals(this.dayOfWeek, reservation.dayOfWeek) &&
        Objects.equals(this.time, reservation.time);
  }

  @Override
  public int hashCode() {
    return Objects.hash(idClient, activity, dayOfWeek, time);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Reservation {\n");
    sb.append("    idClient: ").append(toIndentedString(idClient)).append("\n");
    sb.append("    activity: ").append(toIndentedString(activity)).append("\n");
    sb.append("    dayOfWeek: ").append(toIndentedString(dayOfWeek)).append("\n");
    sb.append("    time: ").append(toIndentedString(time)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

