package com.ejemplo.api.resource;

import com.ejemplo.api.model.ApiError;
import com.ejemplo.api.model.Confirmation; // <-- Importa el modelo generado
import com.ejemplo.api.model.Reservation; // <-- Importa el modelo generado
import com.ejemplo.api.service.ReservationService; // <-- Importa el servicio

import jakarta.inject.Inject; // <-- Importante para inyección de dependencias
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/api/v1") // Prefijo base de la API
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ReservationResource {

    // Inyección de dependencias con CDI
    @Inject
    ReservationService reservationService; // <-- Inyecta el servicio

    @POST
    @Path("/reservations")
    public Response crearReservation(@Valid Reservation reservationRequest) {
        // Por ahora, solo simularemos que lo guardamos
        System.out.println("Resource - Reservation recibido: " + reservationRequest.getIdClient());

        // Simulamos que la DB le asigna un ID
        Confirmation confirmationResponse = reservationService.createReservation(reservationRequest);

        // Devolvemos la respuesta de confirmación con código 201 (CREATED)
        return Response.status(Response.Status.CREATED).entity(confirmationResponse).build();
    }

    @GET
    @Path("/reservations/{reservationId}")
    public Response obtenerReservationPorId(@PathParam("reservationId") Integer reservationId) // <-- Nota el @PathParam
    {
        System.out.println("Resource - Buscando Reservation con ID: " + reservationId);

        // Validación básica del ID
        if (reservationId == null || reservationId < 1 || reservationId > 999999) {
            ApiError errorResponse = new ApiError();
            errorResponse.setCode("400");
            errorResponse.setMessage("El ID de la reserva es inválido. Debe estar entre 1 y 999999.");
            errorResponse.setDetails("ID proporcionado: " + reservationId);

            return Response.status(Response.Status.BAD_REQUEST).entity(errorResponse).build();
        }

        // El controller delega la lógica al servicio
        Confirmation confirmationResponse = reservationService.getReservationById(reservationId);

        // Devolvemos el reservation con código 200 (OK)
        return Response.ok(confirmationResponse).build();
    }
}
