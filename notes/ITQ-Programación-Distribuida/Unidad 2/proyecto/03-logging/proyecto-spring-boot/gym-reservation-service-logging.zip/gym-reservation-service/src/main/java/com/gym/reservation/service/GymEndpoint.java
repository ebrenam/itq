package com.gym.reservation.service;

import java.util.ArrayList;

// Importación del logger SLF4J
import org.slf4j.LoggerFactory;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.gym.reservation.dto.CancelConfirmation;
import com.gym.reservation.dto.CancelReservation;
import com.gym.reservation.dto.Confirmation;
import com.gym.reservation.dto.ConfirmationType;
import com.gym.reservation.dto.Confirmations;
import com.gym.reservation.dto.Reservation;
import com.gym.reservation.dto.SearchCriteria;

@Endpoint
public class GymEndpoint {

    // Definición del logger usando SLF4J
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(GymEndpoint.class);

	private static final String NAMESPACE_URI = "http://com.gym";
	
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "reservation")
    @ResponsePayload
    public Confirmation createReservation(@RequestPayload Reservation request) {

        // No se recomienda usar System.out.println en aplicaciones reales
        // System.out.println("Reservación recibida");

        // Uso del logger para diferentes niveles de logging
        logger.error("ERROR - Reservation request received {}", request.getReservation().getIdClient());
        logger.warn("WARN - Reservation request received {}", request.getReservation().getIdClient());
        logger.debug("DEBUG - Reservation request received {}", request.getReservation().getIdClient());
        logger.info("INFO - Reservation request received {}", request.getReservation().getIdClient());
        logger.trace("TRACE - Reservation request received {}", request.getReservation().getIdClient());

        Confirmation response = new Confirmation ();
        ConfirmationType confirmationType = new ConfirmationType ();
        
        confirmationType.setIdReservation(123);
        confirmationType.setIdRoom(20);
        confirmationType.setInstructor("Paquito");

        response.setConfirmation(confirmationType);
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "cancelReservation")
    @ResponsePayload
    public CancelConfirmation cancelReservation(@RequestPayload CancelReservation request) {
        CancelConfirmation response = new CancelConfirmation ();
        response.setIdReservation(request.getIdReservation());
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "searchCriteria")
    @ResponsePayload
    public Confirmations cancelReservation(@RequestPayload SearchCriteria request) {
    	Confirmations response = new Confirmations ();
    	ArrayList<ConfirmationType> confirmations = new ArrayList<ConfirmationType>();
    	
    	ConfirmationType confirmation = new ConfirmationType();
    	confirmation.setIdReservation(11);
    	confirmation.setIdRoom(555);
    	confirmation.setInstructor("juanito");
    	
       	confirmations.add(confirmation);

     	confirmation.setIdReservation(33);
     	confirmation.setIdRoom(33);
     	confirmation.setInstructor("pedrito");
     	
     	confirmations.add(confirmation);

    	response.setConfirmation(confirmations);
        return response;
    }

}
