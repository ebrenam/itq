package com.ejemplo.api.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.io.Serializable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Confirmación de reserva
 */

@Schema(name = "Confirmation", description = "Confirmación de reserva")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-29T15:49:04.223524-06:00[America/Mexico_City]")
public class Confirmation implements Serializable {

  private static final long serialVersionUID = 1L;

  private Integer idReservation;

  private Integer idRoom;

  private String instructor;

  private Double discount;

  public Confirmation() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public Confirmation(Integer idReservation, Integer idRoom) {
    this.idReservation = idReservation;
    this.idRoom = idRoom;
  }

  public Confirmation idReservation(Integer idReservation) {
    this.idReservation = idReservation;
    return this;
  }

  /**
   * ID único de la reserva
   * minimum: 1
   * maximum: 999999
   * @return idReservation
  */
  @NotNull @Min(1) @Max(999999) 
  @Schema(name = "idReservation", example = "12345", description = "ID único de la reserva", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("idReservation")
  public Integer getIdReservation() {
    return idReservation;
  }

  public void setIdReservation(Integer idReservation) {
    this.idReservation = idReservation;
  }

  public Confirmation idRoom(Integer idRoom) {
    this.idRoom = idRoom;
    return this;
  }

  /**
   * ID de la sala asignada
   * minimum: 1
   * maximum: 20
   * @return idRoom
  */
  @NotNull @Min(1) @Max(20) 
  @Schema(name = "idRoom", example = "5", description = "ID de la sala asignada", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("idRoom")
  public Integer getIdRoom() {
    return idRoom;
  }

  public void setIdRoom(Integer idRoom) {
    this.idRoom = idRoom;
  }

  public Confirmation instructor(String instructor) {
    this.instructor = instructor;
    return this;
  }

  /**
   * Nombre del instructor asignado
   * @return instructor
  */
  @Size(max = 255) 
  @Schema(name = "instructor", example = "María García", description = "Nombre del instructor asignado", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("instructor")
  public String getInstructor() {
    return instructor;
  }

  public void setInstructor(String instructor) {
    this.instructor = instructor;
  }

  public Confirmation discount(Double discount) {
    this.discount = discount;
    return this;
  }

  /**
   * Descuento aplicado a la reserva
   * minimum: 0.0
   * maximum: 999.99
   * @return discount
  */
  @DecimalMin("0.0") @DecimalMax("999.99") 
  @Schema(name = "discount", example = "127.5", description = "Descuento aplicado a la reserva", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("discount")
  public Double getDiscount() {
    return discount;
  }

  public void setDiscount(Double discount) {
    this.discount = discount;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Confirmation confirmation = (Confirmation) o;
    return Objects.equals(this.idReservation, confirmation.idReservation) &&
        Objects.equals(this.idRoom, confirmation.idRoom) &&
        Objects.equals(this.instructor, confirmation.instructor) &&
        Objects.equals(this.discount, confirmation.discount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(idReservation, idRoom, instructor, discount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Confirmation {\n");
    sb.append("    idReservation: ").append(toIndentedString(idReservation)).append("\n");
    sb.append("    idRoom: ").append(toIndentedString(idRoom)).append("\n");
    sb.append("    instructor: ").append(toIndentedString(instructor)).append("\n");
    sb.append("    discount: ").append(toIndentedString(discount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

