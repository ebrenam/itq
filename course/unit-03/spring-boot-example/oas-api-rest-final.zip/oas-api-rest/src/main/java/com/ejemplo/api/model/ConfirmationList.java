package com.ejemplo.api.model;

import java.net.URI;
import java.util.Objects;
import com.ejemplo.api.model.Confirmation;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.io.Serializable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Lista de confirmaciones de reservas
 */

@Schema(name = "ConfirmationList", description = "Lista de confirmaciones de reservas")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-29T15:49:04.223524-06:00[America/Mexico_City]")
public class ConfirmationList implements Serializable {

  private static final long serialVersionUID = 1L;

  @Valid
  private List<@Valid Confirmation> confirmations;

  private Integer total;

  public ConfirmationList confirmations(List<@Valid Confirmation> confirmations) {
    this.confirmations = confirmations;
    return this;
  }

  public ConfirmationList addConfirmationsItem(Confirmation confirmationsItem) {
    if (this.confirmations == null) {
      this.confirmations = new ArrayList<>();
    }
    this.confirmations.add(confirmationsItem);
    return this;
  }

  /**
   * Array de confirmaciones
   * @return confirmations
  */
  @Valid 
  @Schema(name = "confirmations", description = "Array de confirmaciones", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("confirmations")
  public List<@Valid Confirmation> getConfirmations() {
    return confirmations;
  }

  public void setConfirmations(List<@Valid Confirmation> confirmations) {
    this.confirmations = confirmations;
  }

  public ConfirmationList total(Integer total) {
    this.total = total;
    return this;
  }

  /**
   * Total de reservas encontradas
   * @return total
  */
  
  @Schema(name = "total", example = "2", description = "Total de reservas encontradas", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("total")
  public Integer getTotal() {
    return total;
  }

  public void setTotal(Integer total) {
    this.total = total;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConfirmationList confirmationList = (ConfirmationList) o;
    return Objects.equals(this.confirmations, confirmationList.confirmations) &&
        Objects.equals(this.total, confirmationList.total);
  }

  @Override
  public int hashCode() {
    return Objects.hash(confirmations, total);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConfirmationList {\n");
    sb.append("    confirmations: ").append(toIndentedString(confirmations)).append("\n");
    sb.append("    total: ").append(toIndentedString(total)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

