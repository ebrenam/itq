package com.ejemplo.api.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.time.OffsetDateTime;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.io.Serializable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Confirmación de cancelación
 */

@Schema(name = "CancelConfirmation", description = "Confirmación de cancelación")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-29T15:49:04.223524-06:00[America/Mexico_City]")
public class CancelConfirmation implements Serializable {

  private static final long serialVersionUID = 1L;

  private Integer idReservation;

  /**
   * Estado de la cancelación
   */
  public enum StatusEnum {
    CANCELLED("cancelled"),
    
    FAILED("failed");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StatusEnum fromValue(String value) {
      for (StatusEnum b : StatusEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private StatusEnum status;

  private String message;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private OffsetDateTime cancelledAt;

  public CancelConfirmation() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public CancelConfirmation(Integer idReservation, StatusEnum status) {
    this.idReservation = idReservation;
    this.status = status;
  }

  public CancelConfirmation idReservation(Integer idReservation) {
    this.idReservation = idReservation;
    return this;
  }

  /**
   * ID de la reserva cancelada
   * minimum: 1
   * maximum: 999999
   * @return idReservation
  */
  @NotNull @Min(1) @Max(999999) 
  @Schema(name = "idReservation", example = "12345", description = "ID de la reserva cancelada", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("idReservation")
  public Integer getIdReservation() {
    return idReservation;
  }

  public void setIdReservation(Integer idReservation) {
    this.idReservation = idReservation;
  }

  public CancelConfirmation status(StatusEnum status) {
    this.status = status;
    return this;
  }

  /**
   * Estado de la cancelación
   * @return status
  */
  @NotNull 
  @Schema(name = "status", example = "cancelled", description = "Estado de la cancelación", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("status")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public CancelConfirmation message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Mensaje descriptivo
   * @return message
  */
  @Size(max = 500) 
  @Schema(name = "message", example = "Reserva cancelada exitosamente", description = "Mensaje descriptivo", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public CancelConfirmation cancelledAt(OffsetDateTime cancelledAt) {
    this.cancelledAt = cancelledAt;
    return this;
  }

  /**
   * Fecha y hora de cancelación
   * @return cancelledAt
  */
  @Valid 
  @Schema(name = "cancelledAt", example = "2024-01-15T10:30Z", description = "Fecha y hora de cancelación", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("cancelledAt")
  public OffsetDateTime getCancelledAt() {
    return cancelledAt;
  }

  public void setCancelledAt(OffsetDateTime cancelledAt) {
    this.cancelledAt = cancelledAt;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CancelConfirmation cancelConfirmation = (CancelConfirmation) o;
    return Objects.equals(this.idReservation, cancelConfirmation.idReservation) &&
        Objects.equals(this.status, cancelConfirmation.status) &&
        Objects.equals(this.message, cancelConfirmation.message) &&
        Objects.equals(this.cancelledAt, cancelConfirmation.cancelledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(idReservation, status, message, cancelledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CancelConfirmation {\n");
    sb.append("    idReservation: ").append(toIndentedString(idReservation)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    cancelledAt: ").append(toIndentedString(cancelledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

