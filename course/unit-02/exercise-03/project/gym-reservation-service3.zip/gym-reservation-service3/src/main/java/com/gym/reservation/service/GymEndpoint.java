package com.gym.reservation.service;

import java.util.ArrayList;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.gym.reservation.dto.CancelConfirmation;
import com.gym.reservation.dto.CancelReservation;
import com.gym.reservation.dto.Confirmation;
import com.gym.reservation.dto.ConfirmationType;
import com.gym.reservation.dto.Confirmations;
import com.gym.reservation.dto.Reservation;
import com.gym.reservation.dto.SearchCriteria;

@Endpoint
public class GymEndpoint {
	private static final String NAMESPACE_URI = "http://com.gym";
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "reservation")
	@ResponsePayload
	public Confirmation createReservation(@RequestPayload Reservation request) {
		Confirmation response = new Confirmation ();
		ConfirmationType confirmationType = new ConfirmationType ();
		
		confirmationType.setIdReservation(123);
		confirmationType.setIdRoom(20);
		confirmationType.setInstructor("Paquito");

		response.setConfirmation(confirmationType);
		
		return response;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "cancelReservation")
	@ResponsePayload
	public CancelConfirmation cancelReservation(@RequestPayload CancelReservation request) {
		CancelConfirmation response = new CancelConfirmation ();
		
		response.setIdReservation(request.getIdReservation());
		return response;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "searchCriteria")
	@ResponsePayload
	public Confirmations getReservations(@RequestPayload SearchCriteria request) {
		
		
		Confirmations response = new Confirmations();
		ArrayList<ConfirmationType> confirmations = new ArrayList<ConfirmationType>();
		
		ConfirmationType confirmationType = new ConfirmationType ();
		
		confirmationType.setIdReservation(123);
		confirmationType.setIdRoom(20);
		confirmationType.setInstructor("Paquito");
		confirmations.add(confirmationType);
		
		
		confirmationType = new ConfirmationType ();
		confirmationType.setIdReservation(456);
		confirmationType.setIdRoom(10);
		confirmationType.setInstructor("Sarita");
		
		confirmations.add(confirmationType);
		
		
		response.setConfirmation(confirmations);
		
		return response;
		
	}


}
