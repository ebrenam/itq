//
// Este archivo ha sido generado por Eclipse Implementation of JAXB v3.0.0 
// Visite https://eclipse-ee4j.github.io/jaxb-ri 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2025.09.21 a las 02:04:33 PM CST 
//

@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://com.gym", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.gym.reservation.dto;
