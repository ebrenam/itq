package com.gym.reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymReservationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
