package com.gym.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymReservationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymReservationServiceApplication.class, args);
	}

}
